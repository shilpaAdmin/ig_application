@yield('css')

<!-- App css -->

<link href="{{ URL::asset('assets/css/flag-icon.min.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ URL::asset('assets/css/bootstrap-dark.min.css')}}" id="bootstrap-dark" rel="stylesheet"
    type="text/css" />
<link href="{{ URL::asset('assets/css/bootstrap.min.css')}}" id="bootstrap-light" rel="stylesheet" type="text/css" />
<link href="{{ URL::asset('assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />





<link href="{{ URL::asset('assets/css/app.min.css')}}" id="app-light" rel="stylesheet" type="text/css" />
<link href="{{ URL::asset('assets/css/appnew.min.css')}}" id="app-light" rel="stylesheet" type="text/css" />
<link href="{{ URL::asset('assets/css/appnew1.min.css')}}" id="app-light" rel="stylesheet" type="text/css" />
<link href="{{ URL::asset('assets/css/jquery.nestable.min.css')}}" id="app-light" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/css/sweetalert.css')}}">
<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/libs/datatables/datatables.min.css')}}">